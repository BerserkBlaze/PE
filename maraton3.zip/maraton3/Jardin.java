package maraton3;

import java.io.*;

public class Jardin {
	public static void main(String[] arg) {
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;
		int entrada = 0;
		int salida = 0;
		int valvulas = 0;
		String cadena[];
		int Pesos[];
		int salidas[];
		String rutas[];
		int k = 0;
		try {
			archivo = new File("E:\\Users\\Personal\\Desktop\\Entrada.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			String Inicio;
			while (!(Inicio = br.readLine()).equals("9999 9999 9999")) {
				k++;
				int l = 0;
				System.out.println("Sistema de irrigacion # " + k);
				cadena = Inicio.split(" ");
				entrada = Integer.parseInt(cadena[0]);
				salida = Integer.parseInt(cadena[1]);
				valvulas = Integer.parseInt(cadena[2]);
				rutas = new String[valvulas];
				Pesos = new int[valvulas];
				salidas = new int[salida];
				String aux[] = br.readLine().split(" ");
				String linea;
				for (int j = 0; j < (entrada + salida); j++) {
					linea = br.readLine();
				}
				for (int j = 0; j < valvulas; j++) {
					rutas[j] = br.readLine();
				}
				while ((linea = br.readLine()) != null && !(linea.equals("*"))) {
					l++;
					cadena = linea.split(" ");
					for (int i = 0; i < entrada; i++) {
						Pesos[i] = Integer.parseInt(aux[i]);
					}
					for (int i = 0; i < salida; i++) {
						salidas[i] = 0;
					}
					for (int i = 0; i < valvulas; i++) {
						if (cadena[i].equals("R")) {
							char dir = rutas[i].split(" ")[2].charAt(0);
							int pos = rutas[i].split(" ")[2].charAt(rutas[i].split(" ")[2].length() - 1) - 49;
							if (dir == 'V') {
								Pesos[pos] += Pesos[i];
								Pesos[i] = 0;
							} else if (dir == 'S') {
								salidas[pos] += Pesos[i];
								Pesos[i] = 0;
							}
						} else if (cadena[i].equals("L")) {
							char dir = rutas[i].split(" ")[1].charAt(0);
							int pos = rutas[i].split(" ")[1].charAt(rutas[i].split(" ")[1].length() - 1) - 49;

							if (dir == 'V') {
								Pesos[pos] += Pesos[i];
								Pesos[i] = 0;
							} else if (dir == 'S') {
								salidas[pos] += Pesos[i];
								Pesos[i] = 0;
							}
						}
					}
					System.out.println("Configuracion de valvulas # " + l);
					for (int i = 0; i < salida; i++) {
						System.out.println("Salida # " + (i + 1) + " : flujo " + salidas[i] + " galones/min");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}